<template>
  <view class="gg-form-merge">
    <slot />
  </view>
</template>
<script>

export default {
  name: "GgFormMerge",
  props: {

  },
  data() {
    return {
    };
  },
  created: function () {
  }
};
</script>
    
<style>
.gg-form-merge {
  margin-bottom: 10px;
  background-color: #ffffff;
  overflow: auto;
}
.gg-form-merge /deep/ .gg-form-item {
  float: left;
  box-sizing: border-box;
}
.gg-form-merge /deep/ .gg-form-item:nth-child(n + 2) {
  border-bottom: solid 1px #eee;
}
</style>
