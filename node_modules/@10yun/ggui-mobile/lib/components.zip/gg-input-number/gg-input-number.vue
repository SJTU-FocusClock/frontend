<template>
  <gg-form-item :tip="tip" :must="must" :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth"
    :layout="localLayout" :onQClear="onQClear" :rtip="rtip" :input-value="localVal">
    <view class="gg-input-text">
      <input class="gg-input-text-item" placeholder-class="gg-input-text-item-placeholder" v-model="localVal" type="number" :maxlength="maxlength"
        :disabled="disabled" :placeholder="placeholder" @input="updateInput" />
    </view>
  </gg-form-item>
</template>

<script>
import MixinsInput from '../mixins/mixins-input.js';
export default {
  mixins: [MixinsInput],
  name: "GgInputNumber",
  inject: {
    ggFormGroup: {
      default() {
        return null
      }
    }
  },
  props: {

  },
  data() {
    return {
    };
  },
  watch: {
    value(newVal) {
      this.localVal = this._dealValue(newVal);
    }
  },
  created: function () {
    this.localVal = this._dealValue(this.value);;
  },
  methods: {

    _dealValue(value) {
      if (Object.prototype.toString.call(value) === '[object Number]') {
        return value.toString();
      } else {
        return value;
      }
    }
  }
};
</script>

<style>
.gg-input-text-item {
  height: 35px;
  line-height: 35px;
  font-size: 14px;
}
</style>