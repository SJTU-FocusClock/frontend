<template>
  <view class="gg-search">
    <view class="gg-search-left-box" :style="isSlotDefaule==false?'padding-right:0;':''">
      <view class="gg-search-left-item" ref="ggSearchLeftItem">
        <slot name="default" />
      </view>
    </view>
    <view class="gg-search-center-box">
      <view class="gg-search-center-icon">
        <view class="gg-search-center-icon-y"></view>
        <view class="gg-search-center-icon-line"></view>
      </view>
      <view class="gg-search-center-input-box">
        <input class="gg-search-center-input-item" v-model="localVal" placeholder-class="gg-search-center-input-item-placeholder" type="text"
          :placeholder="placeholder" @input="updateInput" @confirm="onSearch">
      </view>
      <view class="gg-search-center-empty" @tap="onEmpty" v-show="localVal">
        <view class="gg-search-center-empty-t"></view>
        <view class="gg-search-center-empty-d"></view>
      </view>
    </view>
    <view class="gg-search-right-box" @tap="onSearch">
      搜索
    </view>
  </view>
</template>

<script>
export default {
  component: true,
  name: "GgSearch",
  options: {
    addGlobalClass: true,
  },
  props: {
    value: {
      type: String,
      default: ""
    },
    placeholder: {
      type: String,
      default: '请输入'
    },
    disableRealTime: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    value(newVal) {
      this.localVal = newVal;
    }
  },
  data() {
    return {
      localVal: '',
      isSlotDefaule: false
    };
  },
  created: function () {
    this.localVal = this.value;
    this.isSlotDefaule = this.$slots.default ? true : false;
    // console.log(this.disableRealTime);
  },
  methods: {
    updateInput(e) {
      /* 判断是否禁止实时更新父级数据 */
      if (this.disableRealTime === false) {
        this.$emit('input', this.localVal);
      }
    },
    onEmpty() {
      this.localVal = '';
      this.updateInput();
    },
    onSearch() {
      this.$emit('search', this.localVal)
      this.$emit('input', this.localVal);
    }
  }
};
</script> 
<style >
.gg-search {
  height: 40px;
  background-color: #ffffff;
  color: #333333;
  display: flex;
}
.gg-search-left-box {
  line-height: 40px;
  font-size: 14px;
  text-align: center;
  padding: 0 15px;
}
.gg-search-left-item {
  max-width: 70px;
  box-sizing: border-box;
  overflow: hidden;
  white-space: nowrap;
}
.gg-search-center-box {
  background-color: #e5e5e5;
  width: 100%;
  height: 30px;
  margin-top: 5px;
  border-radius: 20px;
  display: flex;
}
.gg-search-center-icon {
  width: 40px;
  line-height: 30px;
  text-align: center;
  position: relative;
}
.gg-search-center-icon-y {
  width: 11px;
  height: 11px;
  border-radius: 50%;
  border: solid 2px #999999;
  position: absolute;
  top: 6px;
  left: 11px;
  box-sizing: unset;
}
.gg-search-center-icon-line {
  width: 2px;
  height: 10px;
  position: absolute;
  top: 16px;
  left: 25px;
  background-color: #999999;
  transform: rotate(-45deg);
}
.gg-search-center-input-box {
  width: calc(100% - 40px - 35px);
}
.gg-search-center-input-item {
  line-height: 30px;
  height: 30px;
}
.gg-search-center-input-item-placeholder {
  color: #999999;
}
.gg-search-center-empty {
  width: 35px;
  line-height: 30px;
  text-align: center;
  position: relative;
}
.gg-search-center-empty-t,
.gg-search-center-empty-d {
  width: 16px;
  height: 2px;
  background-color: #999999;
  border-radius: 2px;
  position: absolute;
  top: 15px;
  left: 10px;
}
.gg-search-center-empty-t {
  transform: rotate(45deg);
}
.gg-search-center-empty-d {
  transform: rotate(-45deg);
}
.gg-search-right-box {
  line-height: 40px;
  width: 60px;
  min-width: 60px;
  text-align: center;
  font-size: 14px;
}
</style>
