<template>
  <view class="gg-block" v-bind:style="ggBoxStyle">
    <slot name="default" />
  </view>
</template>

<script>
export default {
  name: "GgBlock",
  options: {
    addGlobalClass: true,
  },
  props: {
    col: {
      type: [String, Number],
      default: ''
    }
  },
  inject: {
    ggGroupCol: {
      default() {
        return null
      }
    }
  },
  data() {
    return {
      ggBoxStyle: '',
      ggBoxMainStyle: {}
    };
  },
  created: function () {
    this._dealStyle();
  },
  methods: {
    _dealStyle() {
      let col = this.col ? this.col : this.ggGroupCol;
      if (col > 0) {
        this.ggBoxStyle = 'width: calc(100% / ' + col + ' - 10px)';
      }
    },
  }
};
</script> 
<style>
/* #ifdef MP-WEIXIN */
gg-block {
  display: contents;
}
/* #endif */

.gg-block {
  width: calc(100% - 10px);
  margin: 5px 5px;
  display: inline-flex;
  flex-direction: column;
  border-radius: 5px;
  overflow: hidden;
  position: relative;
}
</style>
