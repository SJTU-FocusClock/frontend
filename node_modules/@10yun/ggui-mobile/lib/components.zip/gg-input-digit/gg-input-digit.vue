<template>
  <gg-form-item :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth" :layout="localLayout"
    :onQClear="onQClear" :tip="tip" :rtip="rtip" :must="must" :input-value="localVal">
    <view class="gg-input-text">
      <input class="gg-input-text-item" placeholder-class="gg-input-text-item-placeholder" v-model="localVal" type="digit" :placeholder="placeholder"
        :maxlength="maxlength" :disabled="disabled" @input="updateInput" />
    </view>
  </gg-form-item>
</template>

<script>
import MixinsInput from '../mixins/mixins-input.js';
export default {
  mixins: [MixinsInput],
  name: "GgInputDigit",
  inject: {
    ggFormGroup: {
      default() {
        return null
      }
    }
  },
  props: {
  },
  // 监听动态数据变化
  watch: {
  },
  data() {
    return {
    };
  },
  created: function () {
  },
  methods: {

  }
};
</script>
<style>
.gg-input-text-item {
  height: 35px;
  line-height: 35px;
  font-size: 14px;
}
</style>