<template>
  <gg-form-item :tip="tip" :must="must" :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth"
    :layout="localLayout" :onQClear="onQClear" :rtip="rtip" :input-value="localVal">
    <view class="gg-input-text">
      <input class="gg-input-text-item" placeholder-class="gg-input-text-item-placeholder" v-model="localVal" type="idcard" :maxlength="maxlength"
        :disabled="disabled" :placeholder="placeholder" @input="updateInput" />
    </view>
  </gg-form-item>
</template>

<script>
import MixinsInput from '../mixins/mixins-input.js';
export default {
  mixins: [MixinsInput],
  name: "GgInputIdcard",
  inject: {
    ggFormGroup: {
      default() {
        return null
      }
    }
  },
  props: {

  },
  data() {
    return {
    };
  },
  watch: {

  },
  created: function () {
  },
  methods: {


  }
};
</script>

<style>
.gg-input-text-item {
  height: 35px;
  line-height: 35px;
  font-size: 14px;
}
</style>