<template>
  <view class="gg-skeleton-group">
    <slot />
  </view>
</template>
<script>
export default {
  name: 'GgSkeletonGroup',
  data() {
    return {
    };
  },
  methods: {
  }
}
</script>
<style>
.gg-skeleton-group {
  width: 100%;
  height: 100vh;
  background-color: #fff;
}
</style>