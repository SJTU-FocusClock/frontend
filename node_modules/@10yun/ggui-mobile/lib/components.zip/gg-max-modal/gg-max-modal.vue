<template>
  <view class="gg-bottom-modal gg-modal bottom-modal" :class="show?'show':''">
    <view class="gg-dialog">
      <view class="gg-bar bg-white">
        <view class="action text-blue" @tap="cancel">取消</view>
        <view class="action text-green" @tap="confirm">确定</view>
      </view>
      <view class="padding-xl">
        <slot name="default" />
      </view>
    </view>
  </view>
</template>

<script>
export default {
  name: "GgMaxModal",
  options: {
    addGlobalClass: true,
  },
  props: {
    show: {
      type: Boolean,
      default: false
    },
  },
  watch: {

  },
  data() {
    return {

    };
  },
  created: function () {
  },
  methods: {
    confirm() {
      this.onConfirm(true)
    }, cancel() {
      this.onConfirm(false)
    },
    onConfirm(e) {
      this.$emit('confirm', e);
    }
  }
};
</script> 
<style >
.gg-modal.bottom-modal {
  left: 100%;
}
.gg-modal {
  width: 100%;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  z-index: 999;
  opacity: 0;
  outline: 0;
  backface-visibility: hidden;
  -webkit-perspective: 1104px;
  perspective: 1104px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.2s ease-in-out 0s;
  pointer-events: none;
}
.gg-modal.bottom-modal.show {
  left: 0;
}
.gg-modal.show {
  opacity: 1;
  transition-duration: 0.2s;
  overflow-x: hidden;
  overflow-y: auto;
  pointer-events: auto;
}
.gg-modal.bottom-modal::before {
  vertical-align: bottom;
}
.gg-modal::before {
  content: "\200B";
  display: inline-block;
  height: 100%;
  vertical-align: middle;
}
.gg-modal.bottom-modal .gg-dialog {
  width: 100%;
  border-radius: 0;
  height: 100%;
}
.gg-dialog {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin-left: auto;
  margin-right: auto;
  width: 375px;
  max-width: 100%;
  background-color: #f8f8f8;
  border-radius: 5px;
  overflow: hidden;
}
.bg-white {
  background-color: #ffffff;
  color: #666666;
}
.gg-bar {
  display: flex;
  position: relative;
  align-items: center;
  min-height: 45px;
  -webkit-box-pack: justify;
  -webkit-justify-content: space-between;
  justify-content: space-between;
}
.gg-modal .gg-dialog > .gg-bar:first-child .action {
  min-width: 55px;
  margin-right: 0;
  min-height: 45px;
}
.gg-bar .action:first-child {
  margin-left: 16px;
}
.gg-bar .action:last-child {
  margin-right: 16px !important;
}
.gg-bar .action {
  display: flex;
  align-items: center;
  height: 100%;
  justify-content: center;
  max-width: 100%;
  font-size: 16px;
}
.text-green {
  color: #39b54a;
}
.gg-modal .gg-dialog > .gg-bar:first-child .action {
  min-width: 55px;
  margin-right: 0;
  min-height: 45px;
}
.gg-bar .action {
  display: flex;
  align-items: center;
  height: 100%;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  max-width: 100%;
}
.text-blue {
  color: #0081ff;
}
.padding-xl {
  padding: 10px;
  height: calc(100% - 45px - 20px);
  overflow: auto;
}
</style>
