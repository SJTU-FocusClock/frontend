import MixinsCommon from './mixins-common.js';
let MixinsCheckbox = {
    mixins: [MixinsCommon],
    inject: {
        ccFormGroup: {
            default() {
                return null
            }
        }
    },
    props: {
        label: {
            type: String,
            default: ""
        },
        labelWidth: {
            type: [String, Number],
            default: 0
        },
        layout: {
            type: String,
            default: ""
        },
        dataType: {
            type: String,
            default: 'value'
        },
        //选项数组
        dataLists: {
            type: [Array, String],
            default: []
        },
        //选项数组的网络请求地址，用于获取dataLists但优先级高于dataLists
        dataUrl: {
            type: String,
            default: ''
        },
        //数据类型value的名称
        dataValue: {
            type: String,
            default: 'value'
        },
        //数据类型text的名称
        dataText: {
            type: String,
            default: 'text'
        },
        dataChecked: {
            type: String,
            default: 'checked'
        },
        maxNumber: {
            type: [Number, String],
            default: 0
        }
    },
    watch: {

    },
    data() {
        return {
            localVal: [],
            items: [],
            message: '',
            messageDisplay: false,
        }
    },
    created() {

    },
    methods: {

    }
};

export default MixinsCheckbox;
// export default Object.assign({}, MixinsCommon, CcInputMixins);