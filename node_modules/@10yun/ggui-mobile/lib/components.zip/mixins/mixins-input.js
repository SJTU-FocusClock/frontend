import MixinsCommon from './mixins-common.js';
let MixinsInput = {
    mixins: [MixinsCommon],
    inject: {
        ccFormGroup: {
            default() {
                return null
            }
        }
    },
    props: {
        onQClear: {
            type: Boolean,
            default: false
        },
        value: {
            type: [Number, String],
            default: ""
        },
        maxlength: {
            type: [Number, String],
            default: -1
        },
        disabled: {
            type: Boolean,
            default: false
        },
        rtip: {
            type: String,
            default: ""
        },
        message: {
            type: String,
            default: ""
        },
        messageDisplay: {
            type: Boolean,
            default: false
        },
    },
    watch: {
        value(newVal) {
            this.localVal = newVal;
        }
    },
    data() {
        return {
            localItemStyle: '',
            localVal: ''

        }
    },
    created() {
        this.localVal = this.value;
        this._itemStyle();
    },
    methods: {
        _itemStyle() {
            /* 计算输入框右侧预留空间 */
            let paddingRight = 0;
            if (this.rtip) {
                paddingRight += 20
            }
            if (this.onQClear) {
                paddingRight += 30
            }
            this.localItemStyle = 'margin-right:' + paddingRight + 'px;'
        },
        updateInput(e) {
            this.$emit('input', this.localVal);
        },
        /* 监听自己清除按钮点击事件 */
        onEmpty() {
            this.localVal = '';
            this.updateInput();
        }
    }
};

export default MixinsInput;
// export default Object.assign({}, MixinsCommon, CcInputMixins);