import MixinsCommon from './mixins-common.js';
let MixinsPicker = {
    mixins: [MixinsCommon],
    inject: {
        ccFormGroup: {
            default() {
                return null
            }
        }
    },
    props: {
        // 占位符
        placeholder: {
            type: String,
            default: "请选择"
        },
        message: {
            type: String,
            default: ""
        },
        messageDisplay: {
            type: Boolean,
            default: false
        },
    },
    watch: {

    },
    data() {
        return {

        }
    },
    created() {

    },
    methods: {
        bindPickerCancel() {
            this.iconTop = false
        },
        changeIconTop() {
            this.iconTop = true
        }
    }
};

export default MixinsPicker;
// export default Object.assign({}, MixinsCommon, CcInputMixins);