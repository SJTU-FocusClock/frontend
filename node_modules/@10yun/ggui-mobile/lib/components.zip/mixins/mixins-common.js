var MixinsCommon = {
    props: {
        /* label 内容 */
        label: {
            type: String,
            default: ""
        },
        /* label 宽度 */
        labelWidth: {
            type: [String, Number],
            default: 0
        },
        placeholder: {
            type: String,
            default: "请输入"
        },
        tip: {
            type: String,
            default: ""
        },
        layout: {
            type: String,
            default: ""
        },
        /* 必填标识 */
        must: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            localLabelWidth: 60,
            localLayout: 'row',
        }
    },
    created() {
        this._initLocal();
    },
    methods: {
        _initLocal() {
            if (this.ccFormGroup) {
                this.localLabelWidth = this.labelWidth || this.ccFormGroup.$props.labelWidth;
                this.localLayout = this.layout || this.ccFormGroup.$props.layout;
            } else {
                this.localLabelWidth = this.labelWidth || this.localLabelWidth;
                this.localLayout = this.layout || this.localLayout;
            }
        }
    }
};

export default MixinsCommon;