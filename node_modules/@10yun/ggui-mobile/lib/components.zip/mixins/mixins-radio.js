import MixinsCommon from './mixins-common.js';
let MixinsRadio = {
    mixins: [MixinsCommon],
    inject: {
        ccFormGroup: {
            default() {
                return null
            }
        }
    },
    props: {
        value: {
            type: [String, Number],
            default: ""
        },
        dataType: {
            type: String,
            default: 'value'
        },

        dataUrl: {
            type: String,
            default: ''
        },
        dataValue: {
            type: String,
            default: 'value'
        },
        dataText: {
            type: String,
            default: 'text'
        },
        message: {
            type: String,
            default: ""
        },
        messageDisplay: {
            type: Boolean,
            default: false
        },
    },
    watch: {
        value(newVal) {
            this.localVal = newVal;
            this._dealValue();
        }
    },
    data() {
        return {

        }
    },
    created() {

    },
    methods: {
        _dealValue() {
            //默认Value
            let items = this.items;
            if (this.dataType == 'text') {
                for (let index = 0; index < items.length; index++) {
                    if (this.localVal == items[index].text) {
                        this.itemsValue = items[index].value
                    }

                }
            } else {
                this.itemsValue = this.localVal
            }
        },
        radioChange(e) {
            let value = e.detail.value;
            let localVal = value;
            if (this.dataType == 'text') {
                let items = this.items;
                for (let index = 0; index < items.length; index++) {
                    if (localVal == items[index].value) {
                        localVal = items[index].text
                    }
                }
            }
            this.localVal = localVal;
            this.$emit('input', this.localVal);
        }
    }
};

export default MixinsRadio;
// export default Object.assign({}, MixinsCommon, CcInputMixins);