<template>
  <gg-form-item :tip="tip" :must="must" :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth"
    :layout="localLayout" :onQClear="onQClear" :input-value="localVal">
    <view class="gg-input-text">
      <input class="gg-input-text-item" placeholder-class="gg-input-text-item-placeholder" v-model="localVal" type="text" :maxlength="maxlength"
        :disabled="disabled" password :placeholder="placeholder" @input="updateInput" />
    </view>
  </gg-form-item>
</template>

<script>
import MixinsInput from '../mixins/mixins-input.js';
export default {
  mixins: [MixinsInput],
  name: "GgInputPassword",
  inject: {
    ggFormGroup: {
      default() {
        return null
      }
    }
  },
  props: {

  },
  watch: {

  },
  data() {
    return {
    };
  },
  created: function () {
  },
  methods: {

  }
};
</script>
<style>
.gg-input-text-item {
  height: 35px;
  line-height: 35px;
  font-size: 14px;
}
</style>