<template>
  <view class="gg-bottom-modal">
    <view class="cu-modal bottom-modal" :class="show?'show':''">
      <view class="cu-dialog">
        <view class="cu-bar bg-white">
          <view class="action text-blue" @tap="cancel">取消</view>
          <view class="action text-green" @tap="confirm">确定</view>
        </view>
        <view class="padding-xl">
          <slot name="default" />
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  name: "GgBottomModal",
  options: {
    addGlobalClass: true,
  },
  props: {
    show: {
      type: Boolean,
      default: false
    },
  },
  watch: {

  },
  data() {
    return {

    };
  },
  created: function () {
  },
  methods: {
    confirm() {
      this.onConfirm(true)
    }, cancel() {
      this.onConfirm(false)
    },
    onConfirm(e) {
      this.$emit('confirm', e);
    }
  }
};
</script> 
<style >
.cu-modal.bottom-modal {
  margin-bottom: -552px;
}
.cu-modal {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1110;
  opacity: 0;
  outline: 0;
  text-align: center;
  transform: scale(1.185);
  backface-visibility: hidden;
  -webkit-perspective: 1104px;
  perspective: 1104px;
  background: rgba(0, 0, 0, 0.6);
  transition: all 0.3s ease-in-out 0s;
  pointer-events: none;
}
.cu-modal.bottom-modal.show {
  margin-bottom: 0;
}
.cu-modal.show {
  opacity: 1;
  transition-duration: 0.3s;
  transform: scale(1);
  overflow-x: hidden;
  overflow-y: auto;
  pointer-events: auto;
}
.cu-modal.bottom-modal::before {
  vertical-align: bottom;
}
.cu-modal::before {
  content: "\200B";
  display: inline-block;
  height: 100%;
  vertical-align: middle;
}
.cu-modal.bottom-modal .cu-dialog {
  width: 100%;
  border-radius: 0;
}
.cu-dialog {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin-left: auto;
  margin-right: auto;
  width: 375px;
  max-width: 100%;
  background-color: #f8f8f8;
  border-radius: 5px;
  overflow: hidden;
}
.bg-white {
  background-color: #ffffff;
  color: #666666;
}
.cu-bar {
  display: flex;
  position: relative;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  min-height: 45px;
  -webkit-box-pack: justify;
  -webkit-justify-content: space-between;
  justify-content: space-between;
}
.cu-modal .cu-dialog > .cu-bar:first-child .action {
  min-width: 55px;
  margin-right: 0;
  min-height: 45px;
}
.cu-bar .action:first-child {
  margin-left: 16px;
}
.cu-bar .action:last-child {
  margin-right: 16px !important;
}
.cu-bar .action {
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  height: 100%;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  max-width: 100%;
  font-size: 16px;
}
.text-green {
  color: #39b54a;
}
.cu-modal .cu-dialog > .cu-bar:first-child .action {
  min-width: 55px;
  margin-right: 0;
  min-height: 45px;
}
.cu-bar .action {
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  height: 100%;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  max-width: 100%;
}
.text-blue {
  color: #0081ff;
}
.padding-xl {
  padding: 27px;
  max-height: 500px;
  overflow: auto;
}
</style>
