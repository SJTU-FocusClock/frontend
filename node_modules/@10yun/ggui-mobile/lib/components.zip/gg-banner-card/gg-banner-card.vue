<template>
  <swiper class="gg-banner-card" indicator-dots indicator-color="rgba(255, 255, 255, .6)" indicator-active-color="#ffffff" :autoplay="autoplay"
    :circular="circular" :previous-margin="margin" :next-margin="margin" @change="onChange">
    <swiper-item v-for="(item,index) in localDataLists" :key="index">
      <view class="gg-banner-card-swiper-item">
        <view class="gg-banner-card-swiper-item-box" :class="current == index?'swiper-item-selected':''">
          <image class="gg-banner-card-swiper-item-image" :src="item.image" mode="aspectFill" />
          <view class="gg-banner-card-swiper-item-text" v-if="item.text">
            {{item.text}}
          </view>
        </view>
      </view>
    </swiper-item>
  </swiper>
</template>

<script>
export default {
  name: "GgBannerCard",
  options: {
    addGlobalClass: true,
  },
  props: {
    dataLists: {
      type: Array,
      default: []

    },
    paramConfig: {
      type: Object,
      default: {
      }
    }
  },
  watch: {
    dataLists(newVal) {
      this._dealDataLists();
    }
  },
  data() {
    return {
      localDataLists: [],
      autoplay: true,
      circular: true,
      margin: '35px',
      current: 0,
    };
  },
  created: function () {
    this._dealDataLists();
  },
  methods: {
    _dealDataLists() {
      let localDataLists = [];
      const paramImage = this.paramConfig.image || 'image',
        paramText = this.paramConfig.text || 'text';
      this.dataLists.forEach(element => {
        localDataLists.push({
          image: element[paramImage],
          text: element[paramText]
        })
      });
      this.localDataLists = localDataLists;
    },
    onChange(e) {
      this.current = e.detail.current;
    }
  }
};
</script> 
<style >
.gg-banner-card {
  width: 100%;
  height: 160px;
}
.uni-swiper-item {
  height: 100%;
}
.gg-banner-card-swiper-item {
  height: 100%;
}
.gg-banner-card-swiper-item-box {
  border-radius: 5px;
  overflow: hidden;
  position: relative;
  height: 100%;
  transform: scale(0.87);
  transition: transform 0.2s;
}
.swiper-item-selected {
  transform: scale(1);
}
.gg-banner-card-swiper-item-image {
  height: 100%;
  width: 100%;
}
.gg-banner-card-swiper-item-text {
  font-size: 14px;
  position: absolute;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.6);
  width: calc(100% - 30px);
  height: 30px;
  line-height: 30px;
  padding: 0 15px;
  color: rgba(255, 255, 255, 0.9);
  overflow: hidden;
}
</style>
