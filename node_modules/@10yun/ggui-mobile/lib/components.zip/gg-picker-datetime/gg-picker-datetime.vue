<template>
  <gg-form-item :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth" :layout="localLayout" :isIcon="true"
    :iconTop="iconTop">
    <view class="gg-picker-date-time">
      <picker class="gg-picker-date-item" mode="date" :value="localVal_date" :start="startDate" :end="endDate" @change="bindDateChange"
        :fields="fields" @click="changeIconTop" @cancel="bindPickerCancel">
        <view class="gg-picker-date-text" v-if="localVal_date!=''">{{localVal_date}}</view>
        <view class="gg-picker-item-placeholder" v-else>{{placeholder}}</view>
      </picker>
      <picker class="gg-picker-time-item" mode="time" :value="localVal_time" :start="startTime" :end="endTime" @change="bindTimeChange"
        @click="changeIconTop" @cancel="bindPickerCancel">
        <view class="gg-picker-time-text" v-if="localVal_time!=''">{{localVal_time}}</view>
        <view class="gg-picker-item-placeholder" v-else>{{placeholder}}</view>
      </picker>
    </view>
  </gg-form-item>
</template>

<script>
import MixinsPicker from '../mixins/mixins-picker.js';
export default {
  mixins: [MixinsPicker],
  name: "GgPickerDatetime",
  props: {
    //默认输入框
    value: {
      type: String,
      default: ""
    },
    startDate: {
      type: String,
      default: ""
    },
    endDate: {
      type: String,
      default: ""
    },
    startTime: {
      type: String,
      default: ""
    },
    endTime: {
      type: String,
      default: ""
    },
    fields: {
      type: String,
      default: "day"
    }
  },
  data() {
    return {
      localVal: '',
      localVal_date: "",
      localVal_time: "",
      iconTop: false
    };
  },
  created: function () {
    this.localVal = this.value;
    this.localVal_date = this.localVal.split(' ')[0] || '';
    this.localVal_time = this.localVal.split(' ')[1] || '';
  },
  methods: {
    bindTimeChange: function (e) {
      let value = e.detail.value;
      this.localVal_time = value;
      this.mergeDateTime();
    },
    bindDateChange: function (e) {
      let value = e.detail.value;
      this.localVal_date = value;
      this.mergeDateTime();

    },
    mergeDateTime: function () {
      this.localVal = this.localVal_date + ' ' + this.localVal_time;
      this.$emit('input', this.localVal);
      this.iconTop = false;
    }
  }
};
</script>

<style>
.gg-picker-date-time {
  min-height: 35px;
}
.gg-picker-date-item,
.gg-picker-time-item {
  height: 35px;
  line-height: 35px;
  float: left;
  display: flex;
  width: auto;
  margin-right: 10px;
  min-width: 60px;
}
.gg-picker-time-item {
  min-width: 50px;
  margin-right: 10px;
}
.gg-picker-item-placeholder {
  color: grey;
}
</style>
