<template>
  <gg-form-item :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth" :layout="localLayout" :isIcon="true"
    :iconTop="iconTop">
    <view class="gg-picker-time">
      <picker class="gg-picker-time-item" mode="time" :value="localVal" :start="startTime" :end="endTime" @change="bindTimeChange"
        @cancel="bindPickerCancel" @click="changeIconTop">
        <view class="gg-picker-time-text" v-if="localVal!=''">{{localVal}}</view>
        <view class="gg-picker-time-placeholder" v-else>{{placeholder}}</view>
      </picker>
    </view>
  </gg-form-item>
</template>

<script>
import MixinsPicker from '../mixins/mixins-picker.js';
export default {
  mixins: [MixinsPicker],
  name: "GgPickerTime",
  props: {
    //默认输入框
    value: {
      type: String,
      default: ""
    },
    startTime: {
      type: String,
      default: ""
    },
    endTime: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      localVal: '',
      iconTop: false
    };
  },
  created: function () {
    this.localVal = this.value;
  },
  methods: {
    bindTimeChange: function (e) {
      this.localVal = e.detail.value;
      this.$emit('input', this.localVal);
      this.iconTop = false
    }
  }
};
</script>

<style>
.gg-picker-time {
  min-height: 35px;
}
.gg-picker-time-item {
  height: 35px;
  line-height: 35px;
  float: left;
  margin-right: 10px;
  width: 100%;
}
.gg-picker-time-placeholder {
  color: grey;
}
</style>
