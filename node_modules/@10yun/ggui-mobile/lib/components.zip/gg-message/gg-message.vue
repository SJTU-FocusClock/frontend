<template>
  <view class="gg-message">
    <text v-bind:style="loaclStyle">{{message}}</text>
  </view>
</template>

<script>

export default {
  name: "GgMessage",
  props: {
    message: {
      type: String,
      default: ""
    },
    color: {
      type: String,
      default: "#ff0000"
    }
  },
  data() {
    return {
      loaclStyle: {}
    };
  },
  created: function () {
    this.loaclStyle = { color: this.color }
  }
};
</script>

<style>
.gg-message {
  padding: 10px 10px;
  line-height: 1.5em;
  font-size: 14px;
}
</style>
