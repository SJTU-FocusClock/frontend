<template>
  <view class="gg-form-item" :class="localLayout=='col'?'gg-form-item-col':'gg-form-item-row'">
    <text class="gg-form-item-lebel-title-must" v-if="must == true">*</text>
    <view class="gg-form-item-area">
      <view :class="localLayout=='col'?'gg-form-item-area-col':'gg-form-item-area-row'">
        <view class="gg-form-item-label" :class="localLayout=='col'?'gg-form-item-right-col':'gg-form-item-right-row'" v-bind:style="labelStyle">
          <view class="gg-form-item-lebel-title">
            <text>{{label}}</text>
            <text class="gg-form-item-lebel-tip" v-if="localLayout=='col'&&tip!=''">（{{tip}}）</text>
          </view>
        </view>
        <view class="gg-form-item-right" :class="localLayout=='col'?'gg-form-item-right-col':'gg-form-item-right-row'" v-bind:style="labelRightStyle">
          <view class="gg-form-item-right-item">
            <!-- 插槽 -->
            <slot />
            <!-- 三角形图标 -->
            <view class="gg-form-item-right-item-icon" v-if="isIcon">
              <view class="gg-form-item-right-item-icon-box" :class="iconTop?'gg-form-item-right-item-icon-box-top':''">
                <view class="gg-form-item-right-item-icon-item"></view>
              </view>
            </view>
            <!-- 输入框右侧信息 -->
            <view class="gg-form-item-right-item-right">
              <!-- 一键清空 -->
              <view class="gg-form-item-right-item-right-rtip" v-if="rtip != ''">
                {{rtip}}
              </view>
              <view class="gg-form-item-right-item-empty-icon" @click="onEmpty" v-if="onQClear==true &&inputValue!=''">
                X
              </view>
            </view>
          </view>
          <view class="gg-form-item-right-message" v-if="messageDisplay == true"><text>{{message}}</text></view>
        </view>
      </view>
      <view class="gg-form-item-right-tip" v-if="localLayout=='row'&&tip!=''"><text>{{tip}}</text></view>
    </view>
  </view>
</template>
<script>
import MixinsCommon from '../mixins/mixins-common.js';
export default {
  mixins: [MixinsCommon],
  name: "GgFormItem",
  props: {
    isIcon: {
      type: Boolean,
      default: false
    },
    iconTop: {
      type: Boolean,
      default: false
    },
    //右侧提示(一般用作单位)
    rtip: {
      type: String,
      default: ''
    },
    //一键清除按钮
    onQClear: {
      type: Boolean,
      default: false
    },
    //父级输入框内容
    inputValue: {
      type: [String, Number],
      default: ''
    },
    message: {
      type: String,
      default: ""
    },
    messageDisplay: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      labelStyle: '',
    };
  },
  created: function () {
    this.localLayout = this.layout == "col" ? "col" : "row";
    this.labelStyle = this.localLayout == 'row' ? (this.labelWidth > 0 ? 'width:' + this.labelWidth + 'px;' : 'display:none;') : '';
    this.labelRightStyle = this.localLayout == 'row' && this.labelWidth > 0 ? 'width:' + 'calc(100% - 8px - 20px - ' + this.labelWidth + 'px);' : 'padding-left:0;';
    this.$forceUpdate();
  },
  methods: {
    onEmpty(e) {
      this.$parent.onEmpty();
    }
  }
};
</script>
    
<style>
.gg-form-item {
  font-size: 14px;
  padding-left: 15px;
  background-color: #ffffff;
  position: relative;
}
.gg-form-item-area {
  padding: 5px 0px;
  border-bottom: solid 1px #eee;
}
/* #ifndef  MP-WEIXIN */
.gg-form-item:last-child .gg-form-item-area {
  border: none;
}
/* #endif  */
/* #ifdef MP-WEIXIN */

/* #endif  */
.gg-form-item-area-row {
  display: flex;
}
.gg-input-text-item-placeholder {
  font-size: 14px;
}
.gg-form-item-label {
  height: 35px;
  line-height: 35px;
  width: 60px;
  padding-right: 4px;
  overflow: hidden;
  color: #303133;
  padding-left: 4px;
  box-sizing: unset;
}
.gg-form-item-right {
  /* width: calc(100% - 60px - 4px - 4px - 20px); */
  width: 100%;
  padding-left: 5px;
  padding-right: 15px;
  box-sizing: unset;
}
.gg-form-item-right-item {
  min-height: 35px;
  line-height: 35px;
  position: relative;
  overflow: auto;
}
.gg-form-item-right-item-icon {
  position: absolute;
  width: 15px;
  height: 15px;
  top: 10px;
  right: 10px;
}
.gg-form-item-right-item-icon-box {
  padding-top: 1px;
  transform: rotate(0deg);
  transition: transform 0.4s;
}
.gg-form-item-right-item-icon-box-top {
  transform: rotate(-180deg);
}
.gg-form-item-right-item-icon-item {
  width: 0;
  height: 0;
  border-left: 7.5px solid transparent;
  border-right: 7.5px solid transparent;
  border-top: 11px solid #c0c4cc;
}
.gg-form-item-right-message {
  font-size: 12px;
  color: #fa3534;
  margin-top: 6px;
  line-height: 12px;
}
.gg-form-item-right-col {
  /* padding-left: 0; */
  width: auto;
}
.gg-form-item-right-tip {
  font-size: 12px;
  color: rgba(0, 0, 0, 0.4);
  /* margin-top: 5px; */
  line-height: 1.5em;
}
.gg-form-item-lebel-title-must {
  color: #fa3534;
  /* margin-right: 5px; */
  position: absolute;
  top: 15px;
  left: 8px;
}
.gg-form-item-lebel-tip {
  color: rgba(0, 0, 0, 0.4);
}
.gg-form-item-right-item-right {
  height: 16px;
  position: absolute;
  top: 10px;
  right: 0px;
  overflow: auto;
  z-index: 2;
}
.gg-form-item-right-item-empty-icon {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background-color: rgba(0, 0, 0, 0.4);
  font-size: 8px;
  line-height: 16px;
  text-align: center;
  color: #fff;
  float: left;
  margin-left: 10px;
}
.gg-form-item-right-item-right-rtip {
  width: auto;
  height: 16px;
  font-size: 12px;
  line-height: 16px;
  float: left;
  color: rgba(0, 0, 0, 0.6);
}
</style>

