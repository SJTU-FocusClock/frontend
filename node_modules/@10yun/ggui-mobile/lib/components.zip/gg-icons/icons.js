/* 基础图标库 */
const iconsFiles = require.context('./iconfont/', true, /-icons.js$/);
const iconsMods = iconsFiles.keys().reduce((modules, modulePath) => {
	const moduleName = modulePath.replace(/^\.\/(.*)\.\w+$/, '$1');
	const value = iconsFiles(modulePath);
	modules[moduleName] = value.default;
	return modules;
}, {});
// 初始化
let iconsAll = {};
for (let i in iconsMods) {
	if (iconsMods[i]) {
		iconsAll = Object.assign({}, iconsAll, iconsMods[i]);
	}
}

export default iconsAll
