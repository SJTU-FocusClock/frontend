<template>
  <view class="gg-loading-modal">
    <view class="gg-loading-modal-box" v-if="show">
      <image :src="img" mode="aspectFit"></image>
      <view class="gg-loading-modal-text">{{content}}</view>
    </view>
  </view>
</template>

<script>
export default {
  name: "GgLoadingModal",
  options: {
    addGlobalClass: true,
  },
  props: {
    show: {
      type: Boolean,
      default: false
    },
    img: {
      type: String,
      default: '/static/logo.png'
    },
    content: {
      type: String,
      default: '加载中...'
    }
  },
  watch: {

  },
  data() {
    return {

    };
  },
  created: function () {
  },
  methods: {

  }
};
</script> 
<style >
.gg-loading-modal-box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 77px;
  left: 0;
  margin: auto;
  width: 143px;
  height: 143px;
  background-color: #ffffff;
  border-radius: 5px;
  box-shadow: 0 0 0px 1104px rgba(0, 0, 0, 0.5);
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  align-items: center;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
  -webkit-flex-direction: column;
  flex-direction: column;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  justify-content: center;
  font-size: 15px;
  z-index: 9999;
  line-height: 2.4em;
}
.gg-loading-modal-box::after {
  content: "";
  position: absolute;
  background-color: #ffffff;
  border-radius: 50%;
  width: 110px;
  height: 110px;
  font-size: 10px;
  border-top: 3px solid rgba(0, 0, 0, 0.05);
  border-right: 3px solid rgba(0, 0, 0, 0.05);
  border-bottom: 3px solid rgba(0, 0, 0, 0.05);
  border-left: 3px solid #f37b1d;
  -webkit-animation: cuIcon-spin 1s infinite linear;
  animation: cuIcon-spin 1s infinite linear;
  z-index: -1;
}
.gg-loading-modal-box uni-image {
  width: 38px;
  height: 38px;
}
.gg-loading-modal-text {
  font-size: 14px;
  color: #666666;
}
@keyframes cuIcon-spin {
  0% {
    -webkit-transform: rotate(0);
    transform: rotate(0);
  }

  100% {
    -webkit-transform: rotate(359deg);
    transform: rotate(359deg);
  }
}
</style>
