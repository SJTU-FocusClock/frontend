<template>
  <gg-form-item :tip="tip" :must="must" :label="label" :message="message" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth"
    :layout="localLayout">
    <view class="gg-radio-sex">
      <radio-group @change="radioChange">
        <label class="gg-radio-sex-item" v-for="(item) in items" :key="item.value">
          <view class="">
            <radio :value="item.value" :checked="item.value === itemsValue" style="transform:scale(0.7)" />
          </view>
          <view>{{item.text}}</view>
        </label>
      </radio-group>
    </view>
  </gg-form-item>
</template>

<script>
import MixinsRadio from '../mixins/mixins-radio.js';
export default {
  mixins: [MixinsRadio],
  name: "GgRadio-sex",
  inject: {
    ggFormGroup: {
      default() {
        return null
      }
    }
  },
  props: {

    //是否关闭保密选项
    unsecrecy: {
      type: Boolean,
      default: false
    },

  },
  watch: {

  },
  data() {
    return {
      localVal: '',
      items: [
        { value: '0', text: '保密' },
        { value: '1', text: '男' },
        { value: '2', text: '女' },
      ],
      itemsValue: ''
    };
  },
  created: function () {
    this.localVal = this.value;
    if (this.unsecrecy == true) {
      this.items = [
        { value: '1', text: '男' },
        { value: '2', text: '女' },
      ]
    }
    this._dealValue();
  },
  methods: {



  }
};
</script>

<style>
.gg-radio-sex {
  min-height: 35px;
}
.gg-radio-sex-item {
  height: 35px;
  line-height: 35px;
  float: left;
  display: flex;
  margin-right: 10px;
}
</style>
