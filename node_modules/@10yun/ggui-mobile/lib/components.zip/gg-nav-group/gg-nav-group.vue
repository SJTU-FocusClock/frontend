<template>
  <view class="gg-nav-group">
    <view class="gg-nav-group-title">{{label}}</view>
    <slot />
  </view>
</template>
<script>
export default {
  name: "GgNavGroup",
  props: {
    label: {
      type: String,
      default: '',
    }
  },
  data() {
    return {
    };
  },
  created() {
  }
};
</script>
    
<style>
.gg-nav-group {
  margin-bottom: 10px;
}
.gg-nav-group-title {
  font-size: 12px;
  color: #999999;
  line-height: 25px;
  padding: 0 10px;
}
</style>
