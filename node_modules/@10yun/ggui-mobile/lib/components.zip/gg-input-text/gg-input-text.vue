<template>
  <gg-form-item :tip="tip" :label="label" :message="message" :must="must" :messageDisplay="messageDisplay" :labelWidth="localLabelWidth"
    :layout="localLayout" :onQClear="onQClear" :rtip="rtip" :inputValue="localVal">
    <view class="gg-input-text" ref="onEmpty">
      <input class="gg-input-text-item" :style="localItemStyle" placeholder-class="gg-input-text-item-placeholder" v-model="localVal" type="text"
        :placeholder="placeholder" :maxlength="maxlength" :disabled="disabled" @input="updateInput" />
    </view>
  </gg-form-item>
</template>

<script>
import MixinsInput from '../mixins/mixins-input.js';
export default {
  mixins: [MixinsInput],
  name: "GgInputText",
  options: {
    addGlobalClass: true,
  },
  props: {
    rtip: {
      type: String,
      default: ""
    },
  },
  data() {
    return {
    };
  },
  created: function () {

  },
  methods: {

  }
};
</script> 
<style>
.gg-input-text-item {
  height: 35px;
  line-height: 35px;
  font-size: 14px;
}
.gg-input-text-rtip {
  color: #999;
  width: 50rpx;
  padding: 10rpx 0rpx 10rpx 0;
  position: absolute;
  right: 0;
  top: -7px;
  overflow: hidden;
}
</style>
